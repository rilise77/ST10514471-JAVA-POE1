import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class riliseRegClassTest {

    private riliseRegClass user;

    @BeforeClass
    public static void setUpClass() {
        System.out.println("Starting tests...");
    }

    @AfterClass
    public static void tearDownClass() {
        System.out.println("All tests completed.");
    }

    @Before
    public void setUp() {

        user = new riliseRegClass();

        user.firstName = "Rilise";
        user.surname = "Nedzi";
        user.username = "ri_1";
        user.password = "Password1!";
        user.cellphoneNumber = "+27838968976";
    }

    @After
    public void tearDown() {

        user = null;
    }


    @Test
    public void testCheckUserNameCorrect() {

        boolean result = riliselogin.checkUserName("ri_1");

        assertTrue(result);
    }

    @Test
    public void testCheckUserNameIncorrect() {

        boolean result = riliselogin.checkUserName("rilise");

        assertFalse(result);
    }

  
    @Test
    public void testCheckPasswordComplexityCorrect() {

        boolean result =
                riliselogin.checkPasswordComplexity("Password1!");

        assertTrue(result);
    }

    @Test
    public void testCheckPasswordComplexityIncorrect() {

        boolean result =
                riliselogin.checkPasswordComplexity("password");

        assertFalse(result);
    }

    @Test
    public void testCheckCellPhoneNumberCorrect() {

        boolean result =
                riliselogin.checkCellPhoneNumber("+27838968976");

        assertTrue(result);
    }

    @Test
    public void testCheckCellPhoneNumberIncorrect() {

        boolean result =
                riliselogin.checkCellPhoneNumber("0838968976");

        assertFalse(result);
    }

    @Test
    public void testRegisterUserSuccessful() {

        String result = riliselogin.registerUser(user);

        assertEquals("Registration successful!", result);
    }

    @Test
    public void testRegisterUserUnsuccessful() {

        user.username = "rilise";

        String result = riliselogin.registerUser(user);

        assertEquals(
                "Username is not correctly formatted; "
                + "please ensure that your username contains "
                + "an underscore and is no more than five "
                + "characters in length.",
                result
        );
    }

  
    @Test
    public void testReturnLoginStatusSuccessful() {

        String result =
                riliselogin.returnLoginStatus(user, true);

        assertEquals(
                "Welcome Rilise, Nedzi it is great to see you again.",
                result
        );
    }

    @Test
    public void testReturnLoginStatusUnsuccessful() {

        String result =
                riliselogin.returnLoginStatus(user, false);

        assertEquals(
                "Username or password incorrect, please try again.",
                result
        );
    }
}